import javax.swing.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;



public class GreetServer {
        static char x;
        static int m;
        static String text = "";
        private static ServerSocket serverSocket;
        private static Socket clientSocket;
        private static PrintWriter out;
        private static BufferedReader in;
        public static void start(int port) throws IOException {
                serverSocket = new ServerSocket(port);
                while (true) {
                        clientSocket = serverSocket.accept();
                        out = new PrintWriter(clientSocket.getOutputStream(), true);
                        in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                        String greeting = in.readLine();
                        if (greeting.charAt(0) == '1') {
                                out.println("recognised packet");
                                panel.sendCON(greeting.substring(1));
                        } else if (greeting.charAt(0) == '2') {
                                new Thread() {
                                        public void run() {
                                FileWriter fw = null;
                                try {
                                out.println("recognised packet");
                                panel.sendCON("Trying connection from: "+ clientSocket.getInetAddress().toString().substring(1) + " --- " + greeting.substring(1));
                                fw = new FileWriter("ipTXBO.txt", true);
                                File file = new File("ipTXBO.txt");
                                FileReader fr = new FileReader(file);
                                PrintWriter pw = new PrintWriter (fw);
                                LineNumberReader lnr = new LineNumberReader(fr);
                                BufferedWriter bw = new BufferedWriter(fw);

                                int line;
                                String st;
                                if((st = lnr.readLine()) == null){
                                        pw.write(clientSocket.getInetAddress().toString().substring(1) + "\r\n" + "=" + "\r\n" + greeting.substring(1)+ "\r\n" + "--------------------------\r\n");
                                }else {
                                        boolean done = false;
                                        while ((st = lnr.readLine()) != null) {
                                                System.out.println(st);

                                                if (st.equals(greeting.substring(1))) {
                                                        line = lnr.getLineNumber() - 3;
                                                        Path path = Paths.get(file.getPath());
                                                        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
                                                        lines.set(line, clientSocket.getInetAddress().toString().substring(1));
                                                        Files.write(path, lines, StandardCharsets.UTF_8);
                                                        done = true;

                                                }
                                        }

                                        if(!done){
                                                pw.write(clientSocket.getInetAddress().toString().substring(1) + "\r\n" + "=" + "\r\n" + greeting.substring(1) + "\r\n" + "--------------------------\r\n");

                                        }
                                }

                                pw.close();
                                fw.close();
                                } catch (IOException e) {
                                        e.printStackTrace();
                                }
                                        }
                                }.start();
                        } else{
                                out.println("unrecognised packet");
                        }

                }
        }

        public static void stop() throws IOException {
                clientSocket = serverSocket.accept();
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                in.close();
                out.close();
                clientSocket.close();
                serverSocket.close();
        }

        public static void main(String[] args) throws IOException {

                JFrame frame = new JFrame();
                frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                frame.setBounds(300,300,500,300);
                panel panel = new panel();
                frame.add(panel);
                frame.setVisible(true);

                //GreetServer.start(6666);
                GreetServer server = new GreetServer();

        }
}